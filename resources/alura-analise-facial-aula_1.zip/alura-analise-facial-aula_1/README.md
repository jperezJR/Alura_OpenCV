# Análise Facial

Este repositório é de suporte ao curso, compreendendo os seguintes tópicos:

1. Região de interesse
2. Classificador em cascata de Haar
3. Classificação de faces, empregando os algoritmos de Eigenfaces, Fisherfaces e LBPH
4. Marcos faciais
5. Extração de marcos faciais com DLib
6. Análise com vídeos
7. Casos de uso com marcos faciais
